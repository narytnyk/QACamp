package Testng;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Parameters {

    public int add(int a, int b) {
        return a + b;
    }
    @org.testng.annotations.Parameters({ "number1", "number2", "sum" })
    @Test
    public void testAdd(int number1, int number2, int sum) {
        Parameters parameters = new Parameters();
        Assert.assertEquals(parameters.add(number1, number2), sum);
    }
}
