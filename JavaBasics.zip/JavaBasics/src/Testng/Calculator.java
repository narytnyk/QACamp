package Testng;

import org.testng.Assert;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.Test;

public class Calculator {
    private int add(int x, int y) {
        return x+y;
    }
    @Test(groups = "possitive")
    public void firstTest(){
        int expectedResult = 5;
        Assert.assertEquals(add(2,3), expectedResult);
    }

    private int substract(int x, int y){
        return x-y;
    }
    @Test(groups = "possitive")
    public void secondTest(){
        int expectedResult = 2;
        Assert.assertEquals(substract(6,4), expectedResult);
    }

    private int multiply(int x, int y){

        return x*y;
    }
    @Test(groups = "negative")
    private void thirdTest(){
        int expectedResult = 8;
        Assert.assertEquals(multiply(3,2), expectedResult);
    }

    private int divide(int x, int y){

        return x/y;
    }
    @Test(groups = "negative")
    public void forthTest(){
        int expectedResult = 4;
        Assert.assertEquals(divide(8,4), expectedResult);
    }

    private int modulus(int x, int y){

        return x%y;
    }
    @Test(groups = "possitive")
    public void fifthTest(){
        int expectedResult = 0;
        Assert.assertEquals(modulus(20,10), expectedResult);
    }

    private  int divideNeg(int x, int y){

        return x/y;
    }
    @Test(groups = "negative")
    public void sixthTest(){
        int expectedResult = 2;
        Assert.assertEquals(divideNeg(10,2),expectedResult);
    }

    @BeforeGroups("possitive")
    public void processing() {
        System.out.println("processing...");
    }

    @AfterGroups("possitive")
    public void cleanDB() {
        System.out.println("counted!");
    }

    @BeforeGroups("negative")
    public void counting() {
        System.out.println("counting...");
    }
    @AfterGroups("negative")
    public void error() {
        System.out.println("error");
    }

}



