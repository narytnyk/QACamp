package libraries;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;

public class Properties {
    public static void main(String[] args) {
        Properties properties = new Properties();
        FileOutputStream fileOutputStream = null;
        try {
            //fileOutputStream = new FileOutputStream("config.properties");

            PrintWriter writer = new PrintWriter("config.properties", "UTF-8");
            writer.println(properties);
            writer.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        properties = new Properties();
        properties.setProperty("Opera", "1");
        properties.setProperty("Chrome", "2");
    }

    private void setProperty(String opera, String s) {
    }


}