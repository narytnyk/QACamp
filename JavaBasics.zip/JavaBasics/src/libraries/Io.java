package libraries;

import jdk.management.resource.internal.inst.FileOutputStreamRMHooks;

import java.io.*;

public class Io {
    public static void main(String args[]) throws IOException {
        DataOutputStream dataOut = new DataOutputStream(new FileOutputStream("src/file.txt"));
        dataOut.writeUTF("ELEKS QA Camp");

        DataInputStream dataIn = new DataInputStream(new FileInputStream("src/file.txt"));
        while (dataIn.available() > 0) {
            String k = dataIn.readUTF();
        }
    }
}







