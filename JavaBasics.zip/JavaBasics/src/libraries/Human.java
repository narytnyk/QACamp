package libraries;

import java.io.*;

public class Human implements Serializable{
    public String name;
    public int age;

    public Human(String name, int age) {
        this.name = name;
        this.age = age;
    }
}

    class Serialization {
        public static void main(String args[]) throws IOException {

            Human human = new Human("Petro", 27);

            FileOutputStream fileOut = new FileOutputStream("human.ser");
            try (ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
                out.writeObject(human);
            }
        }
    }

    class Deserialiation {
        public static void main(String[] args) throws IOException {
            Human human = null;
            try (FileInputStream fileToRead = new FileInputStream("human.ser")) {
                ObjectInputStream in = new ObjectInputStream(fileToRead);
            }
        }
    }

