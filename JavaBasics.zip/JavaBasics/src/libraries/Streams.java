package libraries;

import java.util.*;

public class Streams {
    public static void main(String []args) {
        Integer[] sourceArray = { 0, 1, 2, 3, 4, 32, 5, 9, 11,43, 17, 22 };
        List<Integer> targetList = Arrays.asList(sourceArray);

        System.out.println("max - " + targetList.stream().max(Integer::compare).get());
        System.out.println("min - " + targetList.stream().min(Integer::compare).get());
        targetList.stream() //
                .mapToInt(i -> i) //
                .average() //
                .ifPresent(avg -> System.out.println("average - " + avg));

        Comparator<Integer> normal = Integer::compare;
        Comparator<Integer> reversed = normal.reversed();
        Collections.sort(targetList, reversed);

        targetList
                .stream()
                .forEach(e -> System.out.print(e + " "));//descending sorting

        targetList.stream()
                .filter(value -> value % 2 == 0)
                .forEach(System.out::println);//filtering even numbers

    }
}
