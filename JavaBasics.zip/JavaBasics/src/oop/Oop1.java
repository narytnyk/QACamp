package oop;

public class Oop1 {

    public static void main(String []args) {
        Men aragorn = new Men();
        aragorn.sleep();
        aragorn.talk();
    }

    public static abstract class Human {
        private String name;

        public void sleep () {
            System.out.println("I sleep");
        }
    }

    public static class Men extends Human implements iTalk{
        @Override
        public void sleep(){
            System.out.println("I sleep one more time");
        }
        public void talk (){
            System.out.println("I talk");
        }
    }
    public interface iTalk {
        public void talk ();
    }
}
