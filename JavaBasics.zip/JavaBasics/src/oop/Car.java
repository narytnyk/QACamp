package oop;

import java.util.Arrays;

public abstract class Car {
    public String getCarType() { return "Unknown"; }
}

class Sedan extends Car {
    public String getCarType() {return "Sedan";}
}

class CarFactory {
    public static Car createCar(String what) {
        if (what.equals("Sedan")) {return new Sedan();}
        return null;
    }
}
class Buyer{
    public  static void main(String args[]){
        Car[] request = new Car [5];
        request[0] = CarFactory.createCar("Sedan");
        request[1] = CarFactory.createCar("Hatchback");
        request[2] = CarFactory.createCar("Mini");
        request[3] = CarFactory.createCar("Limousine");
        request[4] = CarFactory.createCar("Suv");
        }
}


