package oop;

public class Email {

    private static Email INSTANCE =
            new Email();
    public static Email getInstance() {
        return INSTANCE;
    }

    private Email() {

    }

    private String to;
    private String subject;
    private String cc;
    private String body;
    private int priority;
    private boolean attachment = false;

    public static void main(String []args) {

        Email email = new EmailBuilder("Resignation", "Yuliana")
                .bodyOfTheEmail("Hi")
                .peopleInCopy("Roman")
                .importance(5)
                .attachment(false).build();

        email.show();
}

    public static class EmailBuilder {
        private String to;
        private String subject;
        private String cc;
        private String body;
        private int priority;
        private boolean attachment = false;

     public EmailBuilder(String subject, String to) {
         this.subject = subject;
         this.to = to;
     }


     public EmailBuilder peopleInCopy (String cc){
         this.cc = cc;
         return this;
     }

     public EmailBuilder bodyOfTheEmail (String body){
         this.body = body;
         return this;
     }

     public EmailBuilder importance (int priority){
         this.priority = priority;
         return this;
     }

     public EmailBuilder attachment (boolean attachment){
         this.attachment = attachment;
         return  this;
     }

     public Email build(){
         Email email = new Email();
         email.subject = this.subject;
         email.cc = this.cc;
         email.body = this.body;
         email.priority = this.priority;
         email.attachment = this.attachment;
         email.to = this.to;

         return email;
     }

    }
    public void show(){

        System.out.println("To: " + to +" Subject: " + subject+"\n" + "Body: " + body);
    }

    public void sendMessage(String email){

        System.out.println("Email " + email);
    }




}


