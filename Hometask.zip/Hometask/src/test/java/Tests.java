import org.testng.Assert;
import org.testng.annotations.Test;

public class Tests {
    private int add(int x, int y) {
        return x+y;
    }
    @Test
    public void firstTest(){
        int expectedResult = 5;
        Assert.assertEquals(add(2,3), expectedResult);
    }

    private int substract(int x, int y){

        return x-y;
    }
    @Test
    public void secondTest(){
        int expectedResult = 2;
        Assert.assertEquals(substract(6,4), expectedResult);
    }

    private int multiply(int x, int y){

        return x*y;
    }
    @Test
    private void thirdTest(){
        int expectedResult = 8;
        Assert.assertEquals(multiply(3,2), expectedResult);
    }

    private int divide(int x, int y){

        return x/y;
    }
    @Test
    public void forthTest(){
        int expectedResult = 4;
        Assert.assertEquals(divide(8,4), expectedResult);
    }

    private int modulus(int x, int y){

        return x%y;
    }
    @Test
    public void fifthTest(){
        int expectedResult = 0;
        Assert.assertEquals(modulus(20,10), expectedResult);
    }

    private  int divideNeg(int x, int y){

        return x/y;
    }
    @Test
    public void sixthTest(){
        int expectedResult = 5;
        Assert.assertEquals(divideNeg(10,2),expectedResult);
    }

}
